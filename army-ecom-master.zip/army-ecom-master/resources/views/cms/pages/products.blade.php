app/Http/Controllers/CMS/Products 
app/Http/Controllers/Website/ProductController
routes/web.php
resources/cms/*
resources/website/*